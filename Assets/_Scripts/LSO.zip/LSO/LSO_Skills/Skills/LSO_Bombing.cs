using System;
using System.Collections;
using KSY.HealthSystem;
using UnityEngine;

public class LSO_Bombing : LSO_PlayerMovement,LSO_ISkill
{
    
    private GameObject player;
    private KSY_Health health;
    private int damage = 30;
    
    public float scanRange = 5;
    public LayerMask targetLayer;
    public Collider2D[] targets;

    private void Start()
    {
        //player
    }

    private void FixedUpdate()
    {
        if (player == null) return;
        targets = Physics2D.OverlapCircleAll(player.transform.position, scanRange, targetLayer);
    }

    public void UseSkill()
    {
        Debug.Log("Use Skill");
        Debug.Log(player);
        NKY_Health health;
        if (!player.TryGetComponent<NKY_Health>(out health)) 
            return;
        NKY_DamageData data = NKY_DamageData.Create(health, 30);
        health.GetDamage(data);

        foreach (Collider2D hit in targets)
        {
            Debug.Log(hit.name);
            Destroy(hit);
            if (!hit.TryGetComponent<NKY_Health>(out health)) return;
            NKY_DamageData data2 = NKY_DamageData.Create(health, 30);
            health.GetDamage(data2);
        }
    }

    public IEnumerator CoolTime(float time)
    {
        throw new System.NotImplementedException();
    }
}
